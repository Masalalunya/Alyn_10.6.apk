# Keep nothing by default in this skeleton project.
